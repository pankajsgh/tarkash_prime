import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../extra_charge/model/extra_charge_controller.dart';
import '../purchase_controller.dart';

class ChallanPage extends StatelessWidget {
  final PurchaseController controller;
  final ExtraChargeController extraChargeController;

  const ChallanPage({
    super.key,
    required this.controller,
    required this.extraChargeController,
  });

  @override
  Widget build(BuildContext context) {
   
    return ListenableBuilder(
      listenable: extraChargeController,
      builder: (context, _) {
        return ListenableBuilder(
          listenable: controller,
          builder: (context, _) {
            return Scaffold(
              backgroundColor: const Color(0xffEEF2F7),
              appBar: AppBar(
                elevation: 0,
                backgroundColor: Colors.white,
                foregroundColor: const Color(0xff111827),
                title: const Text(
                  'Purchase Challan',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                actions: [
                  Padding(
                    padding: const EdgeInsets.only(right: 15),
                    child: ElevatedButton.icon(
                      onPressed: () async {
                        await _generatePdf(context);
                      },
                      icon: const Icon(
                        Icons.picture_as_pdf_rounded,
                        size: 18,
                      ),
                      label: const Text('Generate PDF'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xff2563EB),
                        foregroundColor: Colors.white,
                        elevation: 0,
                        padding: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 12,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(7),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              body: Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      padding: const EdgeInsets.all(25),
                      child: Center(
                        child: Container(
                          width: 850,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(8),
                            boxShadow: const [
                              BoxShadow(
                                blurRadius: 20,
                                offset: Offset(0, 8),
                                color: Color(0x12000000),
                              ),
                            ],
                          ),
                          padding: const EdgeInsets.all(35),
                          child: _buildChallanView(),
                        ),
                      ),
                    ),
                  ),

                  // Bottom PDF button
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(14),
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 10,
                          color: Color(0x18000000),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          'Grand Total: ₹ ${_money(_grandTotal)}',
                          style: const TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.w700,
                            color: Color(0xff111827),
                          ),
                        ),
                        const SizedBox(width: 20),
                        SizedBox(
                          height: 44,
                          child: ElevatedButton.icon(
                            onPressed: () async {
                              await _generatePdf(context);
                            },
                            icon: const Icon(
                              Icons.picture_as_pdf_rounded,
                              size: 18,
                            ),
                            label: const Text(
                              'Generate PDF',
                              style: TextStyle(
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                              backgroundColor:
                              const Color(0xff2563EB),
                              foregroundColor: Colors.white,
                              elevation: 0,
                              padding: const EdgeInsets.symmetric(
                                horizontal: 20,
                              ),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(7),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  // ============================================================
  // CHALLAN VIEW
  // ============================================================

  Widget _buildChallanView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _challanHeader(),

        const SizedBox(height: 18),

        _sectionTitle('CHALLAN INFORMATION'),

        const SizedBox(height: 7),

        _challanInformation(),

        const SizedBox(height: 20),

        _sectionTitle('PRODUCT DETAILS'),

        const SizedBox(height: 7),

        _productTable(),

        const SizedBox(height: 18),

        _extraChargeSection(),

        const SizedBox(height: 18),

        _summarySection(),

        const SizedBox(height: 18),

        _remarkSection(),

        const SizedBox(height: 50),

        _signatureSection(),
      ],
    );
  }

  // ============================================================
  // HEADER
  // ============================================================

  Widget _challanHeader() {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 20,
        vertical: 18,
      ),
      decoration: BoxDecoration(
        color: const Color(0xffF8FAFC),
        border: Border.all(
          color: const Color(0xffCBD5E1),
        ),
        borderRadius: BorderRadius.circular(7),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: const Color(0xff2563EB),
              borderRadius: BorderRadius.circular(8),
            ),
            child: const Icon(
              Icons.receipt_long_rounded,
              color: Colors.white,
              size: 26,
            ),
          ),

          const SizedBox(width: 14),

          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'PURCHASE CHALLAN',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.w800,
                    letterSpacing: .5,
                  ),
                ),
                SizedBox(height: 3),
                Text(
                  'Purchase / Goods Receipt Challan',
                  style: TextStyle(
                    fontSize: 11,
                    color: Color(0xff64748B),
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 7,
            ),
            decoration: BoxDecoration(
              color: const Color(0xffDBEAFE),
              borderRadius: BorderRadius.circular(5),
            ),
            child: Text(
              controller.challanNo.isEmpty
                  ? 'CHALLAN'
                  : controller.challanNo,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Color(0xff1D4ED8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SECTION TITLE
  // ============================================================

  Widget _sectionTitle(String title) {
    return Row(
      children: [
        Container(
          width: 4,
          height: 16,
          decoration: BoxDecoration(
            color: const Color(0xff2563EB),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
        const SizedBox(width: 7),
        Text(
          title,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w800,
            color: Color(0xff1E293B),
            letterSpacing: .3,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // INFORMATION
  // ============================================================

  Widget _challanInformation() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: const Color(0xffCBD5E1),
        ),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Column(
        children: [
          Row(
            children: [
              _infoBox(
                'Challan No.',
                controller.challanNo,
              ),
              _verticalDivider(),
              _infoBox(
                'Date',
                controller.selectedData,
              ),
              _verticalDivider(),
              _infoBox(
                'Supplier',
                _supplierName(),
                flex: 2,
              ),
            ],
          ),

          _horizontalDivider(),

          Row(
            children: [
              _infoBox(
                'GSTIN',
                controller.gstNo,
              ),
              _verticalDivider(),
              _infoBox(
                'Store',
                _storeName(),
              ),
              _verticalDivider(),
              _infoBox(
                'Transport',
                controller.selectedTransport?.transport ?? '',
              ),
            ],
          ),

          _horizontalDivider(),

          Row(
            children: [
              _infoBox(
                'LR No.',
                controller.lrNoController.text,
              ),
              _verticalDivider(),
              _infoBox(
                'LR Date',
                controller.lrDateController.text,
              ),
              _verticalDivider(),
              _infoBox(
                'Agent',
                controller.selectedAgent?.name ?? '',
                flex: 2,
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _infoBox(
      String title,
      String value, {
        int flex = 1,
      }) {
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 10,
          vertical: 9,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 9,
                color: Color(0xff64748B),
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 3),
            Text(
              value.isEmpty ? '-' : value,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w600,
                color: Color(0xff1E293B),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _verticalDivider() {
    return Container(
      width: 1,
      height: 43,
      color: const Color(0xffE2E8F0),
    );
  }

  Widget _horizontalDivider() {
    return Container(
      height: 1,
      color: const Color(0xffE2E8F0),
    );
  }

  // ============================================================
  // PRODUCT TABLE
  // ============================================================

  Widget _productTable() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: const Color(0xffCBD5E1),
        ),
        borderRadius: BorderRadius.circular(6),
      ),
      clipBehavior: Clip.antiAlias,
      child: Table(
        columnWidths: const {
          0: FixedColumnWidth(38),
          1: FlexColumnWidth(3),
          2: FixedColumnWidth(55),
          3: FixedColumnWidth(75),
          4: FixedColumnWidth(60),
          5: FixedColumnWidth(60),
          6: FixedColumnWidth(85),
        },
        children: [
          TableRow(
            decoration: const BoxDecoration(
              color: Color(0xffEFF6FF),
            ),
            children: [
              _tableHeaderCell('No.'),
              _tableHeaderCell('Product'),
              _tableHeaderCell('Qty'),
              _tableHeaderCell('Rate'),
              _tableHeaderCell('GST'),
              _tableHeaderCell('Disc.'),
              _tableHeaderCell('Amount'),
            ],
          ),

          ...List.generate(
            controller.items.length,
                (index) {
              final item = controller.items[index];

              return TableRow(
                children: [
                  _tableCell(
                    '${index + 1}',
                    center: true,
                  ),
                  _tableCell(
                    item.nameController.text.isEmpty
                        ? '-'
                        : item.nameController.text,
                  ),
                  _tableCell(
                    item.quantityController.text,
                    center: true,
                  ),
                  _tableCell(
                    '₹ ${_money(item.amount ?? 0)}',
                    right: true,
                  ),
                  _tableCell(
                    '${item.getGST}%',
                    center: true,
                  ),
                  _tableCell(
                    '${item.discountController.text}%',
                    center: true,
                  ),
                  _tableCell(
                    '₹ ${_money(item.itemFinalPrice)}',
                    right: true,
                    bold: true,
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _tableHeaderCell(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 6,
        vertical: 9,
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w800,
          color: Color(0xff334155),
        ),
      ),
    );
  }

  Widget _tableCell(
      String text, {
        bool right = false,
        bool center = false,
        bool bold = false,
      }) {
    return Container(
      constraints: const BoxConstraints(
        minHeight: 34,
      ),
      alignment: right
          ? Alignment.centerRight
          : center
          ? Alignment.center
          : Alignment.centerLeft,
      padding: const EdgeInsets.symmetric(
        horizontal: 7,
        vertical: 7,
      ),
      decoration: const BoxDecoration(
        border: Border(
          top: BorderSide(
            color: Color(0xffE2E8F0),
          ),
        ),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 10,
          fontWeight:
          bold ? FontWeight.w700 : FontWeight.normal,
          color: const Color(0xff334155),
        ),
      ),
    );
  }

  // ============================================================
  // EXTRA CHARGES / DISCOUNTS
  // ============================================================

  Widget _extraChargeSection() {
    final items = extraChargeController.items;

    if (items.isEmpty) {
      return const SizedBox();
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _sectionTitle('EXTRA CHARGES / DISCOUNTS'),

        const SizedBox(height: 7),

        Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: const Color(0xffCBD5E1),
            ),
            borderRadius: BorderRadius.circular(6),
          ),
          clipBehavior: Clip.antiAlias,
          child: Table(
            columnWidths: const {
              0: FlexColumnWidth(3),
              1: FixedColumnWidth(100),
              2: FixedColumnWidth(70),
              3: FixedColumnWidth(90),
              4: FixedColumnWidth(95),
            },
            children: [
              TableRow(
                decoration: const BoxDecoration(
                  color: Color(0xffF8FAFC),
                ),
                children: [
                  _tableHeaderCell('Description'),
                  _tableHeaderCell('Type'),
                  _tableHeaderCell('Tax'),
                  _tableHeaderCell('Tax Amount'),
                  _tableHeaderCell('Total'),
                ],
              ),
              ...items.map(
                    (item) => TableRow(
                  children: [
                    _tableCell(
                      item.nameController.text.isEmpty
                          ? '-'
                          : item.nameController.text,
                    ),
                    _tableCell(
                      item.isDiscount ? 'Discount' : 'Charge',
                      center: true,
                    ),
                    _tableCell(
                      item.isTaxApplicable
                          ? '${item.taxController.text}%'
                          : '-',
                      center: true,
                    ),
                    _tableCell(
                      '₹ ${_money(item.setTaxAmount(controller.items))}',
                      right: true,
                    ),
                    _tableCell(
                      '₹ ${_money(item.totalAmount)}',
                      right: true,
                      bold: true,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 8),

        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            _smallSummary(
              'Charges',
              extraChargeController.totalCharges,
              const Color(0xffDC2626),
            ),
            const SizedBox(width: 10),
            _smallSummary(
              'Discount',
              extraChargeController.totalDiscounts,
              const Color(0xff16A34A),
            ),
            const SizedBox(width: 10),
            _smallSummary(
              'Tax',
              extraChargeController.totalTax,
              const Color(0xff2563EB),
            ),
          ],
        ),
      ],
    );
  }

  Widget _smallSummary(
      String title,
      double value,
      Color color,
      ) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 10,
        vertical: 6,
      ),
      decoration: BoxDecoration(
        color: color.withOpacity(.06),
        border: Border.all(
          color: color.withOpacity(.25),
        ),
        borderRadius: BorderRadius.circular(5),
      ),
      child: Row(
        children: [
          Text(
            '$title: ',
            style: TextStyle(
              fontSize: 9,
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            '₹ ${_money(value)}',
            style: TextStyle(
              fontSize: 10,
              color: color,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SUMMARY
  // ============================================================

  Widget _summarySection() {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          child: _summaryLeft(),
        ),
        const SizedBox(width: 25),
        SizedBox(
          width: 320,
          child: _summaryRight(),
        ),
      ],
    );
  }

  Widget _summaryLeft() {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xffF8FAFC),
        border: Border.all(
          color: const Color(0xffE2E8F0),
        ),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Summary',
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: Color(0xff334155),
            ),
          ),
          const SizedBox(height: 9),

          _summaryLine(
            'Total Items',
            '${controller.totalItems}',
          ),

          _summaryLine(
            'Total Quantity',
            '${controller.totalQuantity}',
          ),

          _summaryLine(
            'Supplier',
            _supplierName(),
          ),
        ],
      ),
    );
  }

  Widget _summaryRight() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(
          color: const Color(0xffCBD5E1),
        ),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Column(
        children: [
          _totalLine(
            'Value of Goods',
            controller.valueOfGoods,
          ),

          _totalLine(
            'SGST',
            controller.sgst,
          ),

          _totalLine(
            'CGST',
            controller.cgst,
          ),

          if (extraChargeController.totalCharges > 0)
            _totalLine(
              'Extra Charges',
              extraChargeController.totalCharges,
            ),

          if (extraChargeController.totalDiscounts > 0)
            _totalLine(
              'Extra Discount',
              -extraChargeController.totalDiscounts,
              isDiscount: true,
            ),

          _totalLine(
            'Extra Tax',
            extraChargeController.totalTax,
          ),

          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 12,
              vertical: 11,
            ),
            decoration: const BoxDecoration(
              color: Color(0xffEFF6FF),
              border: Border(
                top: BorderSide(
                  color: Color(0xffCBD5E1),
                ),
              ),
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'GRAND TOTAL',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w800,
                      color: Color(0xff1D4ED8),
                    ),
                  ),
                ),
                Text(
                  '₹ ${_money(_grandTotal)}',
                  style: const TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w800,
                    color: Color(0xff1D4ED8),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryLine(
      String title,
      String value,
      ) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 5),
      child: Row(
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 10,
              color: Color(0xff64748B),
            ),
          ),
          const Spacer(),
          Text(
            value,
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _totalLine(
      String title,
      double value, {
        bool isDiscount = false,
      }) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: 12,
        vertical: 7,
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontSize: 10,
                color: Color(0xff64748B),
              ),
            ),
          ),
          Text(
            '${isDiscount ? '-' : ''}₹ ${_money(value.abs())}',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
              color: isDiscount
                  ? const Color(0xff16A34A)
                  : const Color(0xff334155),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // REMARK
  // ============================================================

  Widget _remarkSection() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(
          color: const Color(0xffCBD5E1),
        ),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'REMARK',
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: Color(0xff475569),
            ),
          ),
          const SizedBox(height: 5),
          Text(
            controller.remarkController.text.trim().isEmpty
                ? '-'
                : controller.remarkController.text.trim(),
            style: const TextStyle(
              fontSize: 10,
              color: Color(0xff334155),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SIGNATURE
  // ============================================================

  Widget _signatureSection() {
    return const Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        _Signature(title: 'Prepared By'),
        _Signature(title: 'Checked By'),
        _Signature(title: 'Authorized Signature'),
      ],
    );
  }

  // ============================================================
  // PDF
  // ============================================================

  Future<void> _generatePdf(BuildContext context) async {
    if (!_validate(context)) {
      return;
    }

    try {
      final Uint8List pdfBytes = await _createPdf();

      await Printing.layoutPdf(
        onLayout: (format) async {
          return pdfBytes;
        },
      );
    } catch (e) {
      debugPrint('PDF generation error: $e');

      if (!context.mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Failed to generate PDF: $e',
          ),
        ),
      );
    }
  }

  // ============================================================
  // VALIDATION
  // ============================================================

  bool _validate(BuildContext context) {
    if (controller.challanNo.trim().isEmpty) {
      _showError(context, 'Challan number is required');
      return false;
    }

    if (controller.selectSupplier == null) {
      _showError(context, 'Please select supplier');
      return false;
    }

    if (controller.selectedStore == null) {
      _showError(context, 'Please select store');
      return false;
    }

    if (controller.items.isEmpty) {
      _showError(context, 'Please add at least one product');
      return false;
    }

    for (int i = 0; i < controller.items.length; i++) {
      final item = controller.items[i];

      if (item.product == null) {
        _showError(
          context,
          'Please select product in row ${i + 1}',
        );
        return false;
      }

      if (item.quantity <= 0) {
        _showError(
          context,
          'Invalid quantity in row ${i + 1}',
        );
        return false;
      }
    }

    return true;
  }

  void _showError(
      BuildContext context,
      String message,
      ) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text(message),
      ),
    );
  }

  // ============================================================
  // CREATE PDF
  // ============================================================

  Future<Uint8List> _createPdf() async {
    final pdf = pw.Document();

    final font = pw.Font.helvetica();
    final boldFont = pw.Font.helveticaBold();

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(28),
        build: (context) {
          return [
            _pdfHeader(font, boldFont),

            pw.SizedBox(height: 15),

            _pdfSectionTitle(
              'CHALLAN INFORMATION',
              boldFont,
            ),

            pw.SizedBox(height: 6),

            _pdfInfo(font, boldFont),

            pw.SizedBox(height: 15),

            _pdfSectionTitle(
              'PRODUCT DETAILS',
              boldFont,
            ),

            pw.SizedBox(height: 6),

            _pdfProducts(font, boldFont),

            if (extraChargeController.items.isNotEmpty) ...[
              pw.SizedBox(height: 15),
              _pdfSectionTitle(
                'EXTRA CHARGES / DISCOUNTS',
                boldFont,
              ),
              pw.SizedBox(height: 6),
              _pdfExtraCharges(font, boldFont),
            ],

            pw.SizedBox(height: 15),

            _pdfTotals(font, boldFont),

            pw.SizedBox(height: 15),

            _pdfRemark(font, boldFont),

            pw.SizedBox(height: 35),

            _pdfSignatures(boldFont),
          ];
        },
      ),
    );

    return Uint8List.fromList(
      await pdf.save(),
    );
  }

  // ============================================================
  // PDF HEADER
  // ============================================================

  pw.Widget _pdfHeader(
      pw.Font font,
      pw.Font boldFont,
      ) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey100,
        border: pw.Border.all(
          color: PdfColors.grey500,
        ),
      ),
      child: pw.Row(
        children: [
          pw.Container(
            width: 40,
            height: 40,
            color: PdfColors.blue700,
            child: pw.Center(
              child: pw.Text(
                'PC',
                style: pw.TextStyle(
                  font: boldFont,
                  color: PdfColors.white,
                  fontSize: 13,
                ),
              ),
            ),
          ),
          pw.SizedBox(width: 12),
          pw.Expanded(
            child: pw.Column(
              crossAxisAlignment:
              pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  'PURCHASE CHALLAN',
                  style: pw.TextStyle(
                    font: boldFont,
                    fontSize: 19,
                  ),
                ),
                pw.SizedBox(height: 3),
                pw.Text(
                  'Purchase / Goods Receipt Challan',
                  style: pw.TextStyle(
                    font: font,
                    fontSize: 8,
                    color: PdfColors.grey700,
                  ),
                ),
              ],
            ),
          ),
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 6,
            ),
            color: PdfColors.blue50,
            child: pw.Text(
              controller.challanNo.isEmpty
                  ? 'CHALLAN'
                  : controller.challanNo,
              style: pw.TextStyle(
                font: boldFont,
                fontSize: 9,
                color: PdfColors.blue800,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // PDF SECTION TITLE
  // ============================================================

  pw.Widget _pdfSectionTitle(
      String title,
      pw.Font font,
      ) {
    return pw.Row(
      children: [
        pw.Container(
          width: 3,
          height: 12,
          color: PdfColors.blue700,
        ),
        pw.SizedBox(width: 6),
        pw.Text(
          title,
          style: pw.TextStyle(
            font: font,
            fontSize: 9,
            color: PdfColors.grey800,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // PDF INFO
  // ============================================================

  pw.Widget _pdfInfo(
      pw.Font font,
      pw.Font boldFont,
      ) {
    return pw.Table(
      border: pw.TableBorder.all(
        color: PdfColors.grey500,
      ),
      columnWidths: const {
        0: pw.FixedColumnWidth(65),
        1: pw.FlexColumnWidth(2),
        2: pw.FixedColumnWidth(65),
        3: pw.FlexColumnWidth(2),
      },
      children: [
        _pdfInfoRow(
          'Challan No.',
          controller.challanNo,
          'Date',
          controller.selectedData,
          font,
          boldFont,
        ),
        _pdfInfoRow(
          'Supplier',
          _supplierName(),
          'GSTIN',
          controller.gstNo,
          font,
          boldFont,
        ),
        _pdfInfoRow(
          'Store',
          _storeName(),
          'Transport',
          controller.selectedTransport?.transport ?? '',
          font,
          boldFont,
        ),
        _pdfInfoRow(
          'LR No.',
          controller.lrNoController.text,
          'LR Date',
          controller.lrDateController.text,
          font,
          boldFont,
        ),
        _pdfInfoRow(
          'Agent',
          controller.selectedAgent?.name ?? '',
          '',
          '',
          font,
          boldFont,
        ),
      ],
    );
  }

  pw.TableRow _pdfInfoRow(
      String title1,
      String value1,
      String title2,
      String value2,
      pw.Font font,
      pw.Font boldFont,
      ) {
    return pw.TableRow(
      children: [
        _pdfLabel(title1, boldFont),
        _pdfCell(value1, font),
        _pdfLabel(title2, boldFont),
        _pdfCell(value2, font),
      ],
    );
  }

  // ============================================================
  // PDF PRODUCTS
  // ============================================================

  pw.Widget _pdfProducts(
      pw.Font font,
      pw.Font boldFont,
      ) {
    return pw.Table(
      border: pw.TableBorder.all(
        color: PdfColors.grey500,
      ),
      columnWidths: const {
        0: pw.FixedColumnWidth(25),
        1: pw.FlexColumnWidth(3),
        2: pw.FixedColumnWidth(38),
        3: pw.FixedColumnWidth(58),
        4: pw.FixedColumnWidth(45),
        5: pw.FixedColumnWidth(45),
        6: pw.FixedColumnWidth(65),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(
            color: PdfColors.blue50,
          ),
          children: [
            _pdfHeaderCell('No.', boldFont),
            _pdfHeaderCell('Product', boldFont),
            _pdfHeaderCell('Qty', boldFont),
            _pdfHeaderCell('Rate', boldFont),
            _pdfHeaderCell('GST', boldFont),
            _pdfHeaderCell('Disc.', boldFont),
            _pdfHeaderCell('Amount', boldFont),
          ],
        ),

        ...List.generate(
          controller.items.length,
              (index) {
            final item = controller.items[index];

            return pw.TableRow(
              children: [
                _pdfCell(
                  '${index + 1}',
                  font,
                  center: true,
                ),
                _pdfCell(
                  item.nameController.text,
                  font,
                ),
                _pdfCell(
                  item.quantityController.text,
                  font,
                  center: true,
                ),
                _pdfCell(
                  _money(item.amount ?? 0),
                  font,
                  right: true,
                ),
                _pdfCell(
                  '${item.getGST}%',
                  font,
                  center: true,
                ),
                _pdfCell(
                  '${item.discountController.text}%',
                  font,
                  center: true,
                ),
                _pdfCell(
                  _money(item.itemFinalPrice),
                  font,
                  right: true,
                  bold: true,
                ),
              ],
            );
          },
        ),
      ],
    );
  }

  // ============================================================
  // PDF EXTRA CHARGES
  // ============================================================

  pw.Widget _pdfExtraCharges(
      pw.Font font,
      pw.Font boldFont,
      ) {
    return pw.Table(
      border: pw.TableBorder.all(
        color: PdfColors.grey500,
      ),
      columnWidths: const {
        0: pw.FlexColumnWidth(3),
        1: pw.FixedColumnWidth(75),
        2: pw.FixedColumnWidth(50),
        3: pw.FixedColumnWidth(65),
        4: pw.FixedColumnWidth(70),
      },
      children: [
        pw.TableRow(
          decoration: const pw.BoxDecoration(
            color: PdfColors.grey100,
          ),
          children: [
            _pdfHeaderCell('Description', boldFont),
            _pdfHeaderCell('Type', boldFont),
            _pdfHeaderCell('Tax', boldFont),
            _pdfHeaderCell('Tax Amount', boldFont),
            _pdfHeaderCell('Total', boldFont),
          ],
        ),
        ...extraChargeController.items.map(
              (item) {
            return pw.TableRow(
              children: [
                _pdfCell(
                  item.nameController.text.isEmpty
                      ? '-'
                      : item.nameController.text,
                  font,
                ),
                _pdfCell(
                  item.isDiscount ? 'Discount' : 'Charge',
                  font,
                  center: true,
                ),
                _pdfCell(
                  item.isTaxApplicable
                      ? '${item.taxController.text}%'
                      : '-',
                  font,
                  center: true,
                ),
                _pdfCell(
                  _money(
                    item.setTaxAmount(controller.items),
                  ),
                  font,
                  right: true,
                ),
                _pdfCell(
                  _money(item.totalAmount),
                  font,
                  right: true,
                  bold: true,
                ),
              ],
            );
          },
        ),
      ],
    );
  }

  // ============================================================
  // PDF TOTALS
  // ============================================================

  pw.Widget _pdfTotals(
      pw.Font font,
      pw.Font boldFont,
      ) {
    return pw.Align(
      alignment: pw.Alignment.centerRight,
      child: pw.Container(
        width: 250,
        child: pw.Table(
          border: pw.TableBorder.all(
            color: PdfColors.grey500,
          ),
          children: [
            _pdfTotalRow(
              'Value of Goods',
              controller.valueOfGoods,
              font,
            ),
            _pdfTotalRow(
              'SGST',
              controller.sgst,
              font,
            ),
            _pdfTotalRow(
              'CGST',
              controller.cgst,
              font,
            ),
            if (extraChargeController.totalCharges > 0)
              _pdfTotalRow(
                'Extra Charges',
                extraChargeController.totalCharges,
                font,
              ),
            if (extraChargeController.totalDiscounts > 0)
              _pdfTotalRow(
                'Extra Discount',
                -extraChargeController.totalDiscounts,
                font,
                discount: true,
              ),
            if (extraChargeController.totalTax > 0)
              _pdfTotalRow(
                'Extra Tax',
                extraChargeController.totalTax,
                font,
              ),
            pw.TableRow(
              decoration: const pw.BoxDecoration(
                color: PdfColors.blue50,
              ),
              children: [
                _pdfTotalCell(
                  'GRAND TOTAL',
                  boldFont,
                ),
                _pdfTotalCell(
                  _money(_grandTotal),
                  boldFont,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  pw.TableRow _pdfTotalRow(
      String title,
      double value,
      pw.Font font, {
        bool discount = false,
      }) {
    return pw.TableRow(
      children: [
        _pdfCell(title, font),
        _pdfCell(
          '${discount ? '-' : ''}${_money(value.abs())}',
          font,
          right: true,
        ),
      ],
    );
  }

  // ============================================================
  // PDF REMARK
  // ============================================================

  pw.Widget _pdfRemark(
      pw.Font font,
      pw.Font boldFont,
      ) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(8),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(
          color: PdfColors.grey500,
        ),
      ),
      child: pw.Column(
        crossAxisAlignment:
        pw.CrossAxisAlignment.start,
        children: [
          pw.Text(
            'REMARK',
            style: pw.TextStyle(
              font: boldFont,
              fontSize: 8,
            ),
          ),
          pw.SizedBox(height: 4),
          pw.Text(
            controller.remarkController.text.trim().isEmpty
                ? '-'
                : controller.remarkController.text.trim(),
            style: pw.TextStyle(
              font: font,
              fontSize: 8,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // PDF SIGNATURES
  // ============================================================

  pw.Widget _pdfSignatures(
      pw.Font boldFont,
      ) {
    return pw.Row(
      mainAxisAlignment:
      pw.MainAxisAlignment.spaceBetween,
      children: [
        _pdfSignature('Prepared By', boldFont),
        _pdfSignature('Checked By', boldFont),
        _pdfSignature(
          'Authorized Signature',
          boldFont,
        ),
      ],
    );
  }

  pw.Widget _pdfSignature(
      String title,
      pw.Font font,
      ) {
    return pw.Column(
      children: [
        pw.SizedBox(height: 25),
        pw.Container(
          width: 110,
          height: .7,
          color: PdfColors.black,
        ),
        pw.SizedBox(height: 4),
        pw.Text(
          title,
          style: pw.TextStyle(
            font: font,
            fontSize: 8,
          ),
        ),
      ],
    );
  }

  // ============================================================
  // PDF CELLS
  // ============================================================

  pw.Widget _pdfHeaderCell(
      String text,
      pw.Font font,
      ) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(5),
      child: pw.Text(
        text,
        textAlign: pw.TextAlign.center,
        style: pw.TextStyle(
          font: font,
          fontSize: 7,
        ),
      ),
    );
  }

  pw.Widget _pdfLabel(
      String text,
      pw.Font font,
      ) {
    return pw.Container(
      color: PdfColors.grey100,
      padding: const pw.EdgeInsets.all(5),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          font: font,
          fontSize: 7,
        ),
      ),
    );
  }

  pw.Widget _pdfCell(
      String text,
      pw.Font font, {
        bool right = false,
        bool center = false,
        bool bold = false,
      }) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(5),
      child: pw.Text(
        text,
        textAlign: right
            ? pw.TextAlign.right
            : center
            ? pw.TextAlign.center
            : pw.TextAlign.left,
        style: pw.TextStyle(
          font: bold ? pw.Font.helveticaBold() : font,
          fontSize: 7,
        ),
      ),
    );
  }

  pw.Widget _pdfTotalCell(
      String text,
      pw.Font font,
      ) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(7),
      child: pw.Text(
        text,
        textAlign: pw.TextAlign.right,
        style: pw.TextStyle(
          font: font,
          fontSize: 9,
        ),
      ),
    );
  }

  // ============================================================
  // VALUES
  // ============================================================

  String _supplierName() {
    return controller.selectSupplier?.name ?? '';
  }

  String _storeName() {
    return controller.selectedStore?.store ?? '';
  }

  double get _grandTotal {
    /*
     * Base Purchase total
     */
    double total = controller.valueOfGoods +
        controller.sgst +
        controller.cgst;

    /*
     * Extra charges
     */
    total += extraChargeController.totalCharges;

    /*
     * Extra discount
     */
    total -= extraChargeController.totalDiscounts;

    /*
     * Extra charge tax
     */
    total += extraChargeController.totalTax;

    return total;
  }

  String _money(double value) {
    return value.toStringAsFixed(2);
  }
}

// ================================================================
// SIGNATURE
// ================================================================

class _Signature extends StatelessWidget {
  final String title;

  const _Signature({
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 30),
        Container(
          width: 120,
          height: 1,
          color: Colors.black,
        ),
        const SizedBox(height: 5),
        Text(
          title,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            color: Color(0xff334155),
          ),
        ),
      ],
    );
  }
}